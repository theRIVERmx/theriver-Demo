var map;
var slider = document.getElementById('sliderNav');
markers = [];
check = [];

//Slider
console.log("ExecutedCollection");
noUiSlider.create(slider, {
  connect: [false, true, false],
  start: [1, 12 ],
  step: 1,
  range: {
    'min': [  1 ],
    'max': [ 12 ]
  }
});

matrix = slider.noUiSlider.get();

window.collection_callback = function(results) {
  console.log("ExecutedCollection");
  length = results.features.length;
  //console.log(length);
  for (var i = 0; i < length; i++) {
    coords = results.features[i].geometry.coordinates;
    latLng = new google.maps.LatLng(coords[0],coords[1]);
    marker = new google.maps.Marker({
      position: latLng,
      map: map
    });
    openH = results.features[i].properties.open;
    openHA.push(openH);
    markers.push(marker);
  }
}

//MAP Initialize
function initMap() {
  console.log("InitMap");
  openHA = [];
  first = [];
  second =[];

  map = new google.maps.Map(document.getElementById('map'), {
    center: new google.maps.LatLng(2.8, -187.3),
    zoom: 2
  });

  var script = document.createElement('script');
  script.src = "collection.geojson";
  document.getElementsByTagName('head')[0].appendChild(script);
  slider.noUiSlider.on('set', sliderValues);
}

function sliderValues() {
  console.log("SliderBar");
  matrix = slider.noUiSlider.get();
  //console.log(matrix);
  //console.log(openHA);
  console.log(matrix);
  for(var i = 0; i < length; i++){
    first.push(openHA[i][0]);
    second.push(openHA[i][1]);
  }
    for(var j = 0; j < length; j++) {
      //console.log(second);
      //console.log(openHA[i][j]);
      if(first[j] >= matrix[0] && second[j] <= matrix[1] ) {
        console.log(openHA[j]);
        console.log(markers[j]);
        markers[j].setVisible(true);
        //  console.log("Showing");
      }
      else {
        markers[j].setVisible(false);
      }
    }
}
