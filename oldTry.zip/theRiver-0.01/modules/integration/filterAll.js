//window.initJSON();
/* Global Variables to be used */

/* ----- ----- */

/* Check Buttons */
function initButtons () {
  categorieButtons = document.getElementsByClassName('chkBtn');
  conditionalButtons = document.getElementsByName('withCondition');
  normalButtons = document.getElementsByName('withoutCondition');
  buttonsState = [];

  for(var i = 0; i < categorieButtons.length; i++) {
    categorieButtons[i].checked = false;
  }

  for(var i = 0; i < normalButtons.length; i++) {
    normalButtons[i].onchange = initJSON;
  }

  conditionalButtons[0].onchange = createCondition;
  conditionalButtons[1].onchange = joinCondition;
}

function createCondition () {
  if(conditionalButtons[0].checked == true) {
    conditionalButtons[1].checked = false;
  }
  initJSON();
}

function joinCondition () {
  if(conditionalButtons[1].checked == true) {
    conditionalButtons[0].checked = false;
  }
  initJSON();
}
/* ----- -----*/


/* Slider Module */
var slider = document.getElementById('slider');
noUiSlider.create(slider, {
  connect: [false, true, false],
  start: [1, 12 ],
  step: 1,
  range: {
    'min': [  1 ],
    'max': [ 12 ]
  }
});

sliderArray = slider.noUiSlider.get();

slider.noUiSlider.on('set', initJSON);
/* ----- ----- */

/* Loading the JSON file */
//Get JSON Values
function loadJSON (callback) {
  var xObj = new XMLHttpRequest();
  xObj.overrideMimeType("application/json");
  xObj.open('GET', 'collection.geojson', true);
  xObj.onreadystatechange = function () {
    if(xObj.readyState == 4 && xObj.status == '200') {
      callback(xObj.responseText);
    }
  };
  xObj.send(null);
}

function initJSON () {
  //console.log("InitJSON")
  loadJSON(function(response) {
    //Variables to storage the JSON data
    names = [];
    categories = [];
    openDays = [];
    firstValues = [];
    secondValues = [];
    singleOBJ = [];

    //Parse
    json = JSON.parse(response);
    length = json.features.length; //Objective Length JSON

    //Get the JSON properties values
    for(var i = 0; i < length; i++) {
      singleOBJ[i] = json.features[i];
      categories[i] = json.features[i].properties.tags;
      openDays[i] = json.features[i].properties.open;
      names[i] = json.features[i].properties.title;
      firstValues[i] = openDays[i][0];
      secondValues[i] = openDays[i][1];
    } //The for method ends

    main();

  });
}

/* ----- ------ */

/* Functionalities */
initButtons();

function main () {

  valuesToShow = [];
  valuesButtons = [];
  valuesSlide = [];
  //buttons = {stay: false, meet:false, create: false, join: false}
  buttonsSelected = [];
  namesN = [];

  for(var i = 0; i < categorieButtons.length; i++) {
    buttonsState[i] = categorieButtons[i].checked;
  }

  sliderArray = slider.noUiSlider.get();


  for (var i = 0; i < length; i++) {
    if(firstValues[i] >= sliderArray[0] && secondValues[i] <= sliderArray[1]){
      valuesSlide[i] = names[i];
    }
    else {
      //
    }
  }

  for(var i = 0; i < categorieButtons.length; i++){
    if(categorieButtons[i].checked) {
      buttonsSelected.push(categorieButtons[i].id);
    }
  }

  for(var i = 0; i < length; i ++) {
    single = singleOBJ[i];
    for(var j = 0; j < buttonsSelected.length; j ++) {
      console.log(buttonsSelected[j])
      if(single.properties.tags[buttonsSelected[j]]) {
        //console.log(single.properties.tags);
        
        //console.log(single.properties.tags[buttonsSelected[j]]);
      } else {
        //
      }
    }
  }

  for(var i = 0; i < length; i++) {
    if(valuesButtons[i] == valuesSlide[i]) {
      valuesToShow.push(valuesSlide[i]);
    }
  }

  //console.log(valuesToShow)
}
