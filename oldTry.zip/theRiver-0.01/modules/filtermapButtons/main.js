var map;
mapContainer = document.getElementById("map");


function initMap() {
  map = new google.maps.Map(mapContainer, {
    center: { lat: -34, lng: 150 },
    zoom: 8
  });
}
