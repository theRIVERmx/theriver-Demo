//Declared variables
var map;
var slider = document.getElementById('slider');
markers = [];
first = [];
second = [];
check = [];


/*---- Slider ---- */
noUiSlider.create(slider, {
  connect: [false, true, false],
  start: [1, 12 ],
  step: 1,
  range: {
    'min': [ 1 ],
    'max': [ 12 ]
  }
});

//Getting de values of the slider
matrix = slider.noUiSlider.get();
//console.log(matrix);






// start out with filter features set to false, so no filtering happens by default
var filters = {join:false, meet:false, stay:false, create:false}
//console.log(filters);








$(function () {
  conditionalButtons = document.getElementsByClassName('chkBtn');

  $('input[name=withoutCondition]').change(function (e) {
    map_filter(this.id);
    filter_markers();
  });

})











var get_set_options = function() {
  ret_array = []
  for (option in filters) {
    //console.log(option);
    //console.log(filters);
    if (filters[option]) {
      //console.log(filters[option])
      ret_array.push(option)
    }
  }
  //console.log(ret_array);
  return ret_array;
}

var filter_markers = function() {
  set_filters = get_set_options();
  for (i = 0; i < markers.length; i++) {
    marker = markers[i];
    //console.log(marker.properties);
    keep = true;
    for (opt=0; opt<set_filters.length; opt++) {
      if (!marker.properties[set_filters[opt]]) {
        keep = false;
      
      }
    }
    check[opt] = marker[opt];
    marker.setVisible(keep)
  }
}





var map_filter = function(id_val) {
  //console.log("map_filter function ----------------------------------");
   if (filters[id_val]) {
    filters[id_val] = false
  }
   else {
    filters[id_val] = true
  }
  console.log(filters);
}









function loadMarkers() {
  //console.log('creating markers')
  var infoWindow = new google.maps.InfoWindow()
  geojson_url = 'scripts/collection00.geojson'
  $.getJSON(geojson_url, function(result) {
      data = result['features']
      $.each(data, function(key, val) {
        var point = new google.maps.LatLng(
                parseFloat(val['geometry']['coordinates'][0]),
                parseFloat(val['geometry']['coordinates'][1]));
        var titleText = val['properties']['title']
        var imagePlace = val['properties']['image']
        var infoPlace = val['properties']['information']
        openH = val['properties']['open']
        marker = new google.maps.Marker({
          position: point,
          icon: {
            path: 'M0,50 A50,50,0 1 1 100,50 A50,50,0 1 1 0,50 Z',
            fillColor: '#ff8a65',
            fillOpacity: 0.9,
            scale: 0.18,
            strokeColor: '#ff8a65'
          },
          title: titleText,
          map: map,
          properties: val['properties']
         });
        var markerInfo = "<div><h3>" + titleText + "</h3><p>" + infoPlace + "</p><img src=" + imagePlace + "></div>"

        markers.push(marker)
        jsonLength = markers.length;
        first.push(openH[0]);
        second.push(openH[1]);

        marker.addListener('click', function() {
          document.getElementById("boxInfo").style.width = "250px";
          document.getElementById("main").style.marginLeft = "250px";
           $('#information').html(markerInfo)

           document.getElementById("buttonshop").addEventListener("click", displayDate);

           function displayDate() {
               console.log(titleText);
           }
        });
      });
      slider.noUiSlider.on('set', sliderValues);

  });
}










function closeNav() {
    document.getElementById("boxInfo").style.width = "0px";
    document.getElementById("main").style.marginLeft = "0px";
}






// ------------------------- Initialize map container
function initMap() {
  /* ----- Map Styling ----- */
  var styledMapType = new google.maps.StyledMapType(
    [
      {
        "elementType": "geometry",
        "stylers": [
          {
            "color": "#f5f5f5"
          }
        ]
      },
      {
        "elementType": "labels",
        "stylers": [
          {
            "visibility": "off"
          }
        ]
      },
      {
        "elementType": "labels.icon",
        "stylers": [
          {
            "visibility": "off"
          }
        ]
      },
      {
        "elementType": "labels.text.fill",
        "stylers": [
          {
            "color": "#616161"
          }
        ]
      },
      {
        "elementType": "labels.text.stroke",
        "stylers": [
          {
            "color": "#f5f5f5"
          }
        ]
      },
      {
        "featureType": "administrative.land_parcel",
        "stylers": [
          {
            "visibility": "off"
          }
        ]
      },
      {
        "featureType": "administrative.land_parcel",
        "elementType": "labels.text.fill",
        "stylers": [
          {
            "color": "#bdbdbd"
          }
        ]
      },
      {
        "featureType": "administrative.neighborhood",
        "stylers": [
          {
            "visibility": "off"
          }
        ]
      },
      {
        "featureType": "poi",
        "elementType": "geometry",
        "stylers": [
          {
            "color": "#eeeeee"
          }
        ]
      },
      {
        "featureType": "poi",
        "elementType": "labels.text.fill",
        "stylers": [
          {
            "color": "#757575"
          }
        ]
      },
      {
        "featureType": "poi.park",
        "elementType": "geometry",
        "stylers": [
          {
            "color": "#e5e5e5"
          }
        ]
      },
      {
        "featureType": "poi.park",
        "elementType": "labels.text.fill",
        "stylers": [
          {
            "color": "#9e9e9e"
          }
        ]
      },
      {
        "featureType": "road",
        "elementType": "geometry",
        "stylers": [
          {
            "color": "#ffffff"
          }
        ]
      },
      {
        "featureType": "road.arterial",
        "elementType": "labels.text.fill",
        "stylers": [
          {
            "color": "#757575"
          }
        ]
      },
      {
        "featureType": "road.highway",
        "elementType": "geometry",
        "stylers": [
          {
            "color": "#dadada"
          }
        ]
      },
      {
        "featureType": "road.highway",
        "elementType": "labels.text.fill",
        "stylers": [
          {
            "color": "#616161"
          }
        ]
      },
      {
        "featureType": "road.local",
        "elementType": "labels.text.fill",
        "stylers": [
          {
            "color": "#9e9e9e"
          }
        ]
      },
      {
        "featureType": "transit.line",
        "elementType": "geometry",
        "stylers": [
          {
            "color": "#e5e5e5"
          }
        ]
      },
      {
        "featureType": "transit.station",
        "elementType": "geometry",
        "stylers": [
          {
            "color": "#eeeeee"
          }
        ]
      },
      {
        "featureType": "water",
        "elementType": "geometry",
        "stylers": [
          {
            "color": "#c9c9c9"
          }
        ]
      },
      {
        "featureType": "water",
        "elementType": "labels.text.fill",
        "stylers": [
          {
            "color": "#9e9e9e"
          }
        ]
      }
    ],
    {name: 'theRiver'});


    /* ----- Map Styling ----- */
    map_options = {
      zoom: 2,
      mapTypeId: google.maps.MapTypeId.ROADMAP,
      center: {lat: 20, lng: 0},
      mapTypeControlOptions: {
            mapTypeIds: ['styled_map'],
            position: google.maps.ControlPosition.TOP_BOTTOM
          },
      streetViewControl: false
    }
    map_document = document.getElementById('mapLake')
    map = new google.maps.Map(map_document,map_options);
    map.mapTypes.set('styled_map', styledMapType);
    map.setMapTypeId('styled_map');
    loadMarkers()
    google.maps.event.addDomListener(window, "resize", function() {
      var center = map.getCenter();
      google.maps.event.trigger(map, "resize");
      map.setCenter(center);
    });
}








//MapSlider Filtering-------
function sliderValues() {
  matrix = slider.noUiSlider.get();
  //console.log(matrix);
  for(var j = 0; j < jsonLength; j++) {
    if(first[j] >= matrix[0] && second[j] <= matrix[1] ) {
      //console.log(openHA[j]);
      //console.log(markers[j]);
      markers[j].setVisible(true);
      //  console.log("Showing");
    }
    else {
      markers[j].setVisible(false);
    }
  }
}
