//KEYMAP AIzaSyDzDgXvTkp5Y4LQWuzkCZhdM2fRQJAo7ak




/* ----- Setting unchecked buttons ----- */
navButtons = document.getElementsByClassName("wtCn");
for(var i = 0; i < navButtons.length; i ++){
  navButtons[i].checked = false;
}

//navButtons[0].onchange = startingBoxes;
//navButtons[1].onchange = startingBoxes;
navButtons[0].onchange = desactivateJoinButton;
navButtons[1].onchange = desactivateCreateButton;


function desactivateJoinButton() { //Function that desactivate create button
  if(navButtons[0].checked == true) {
    navButtons[1].checked = false;
  }
  //startingBoxes();
}

function desactivateCreateButton() { //Function that desactivate join button
  if(navButtons[1].checked == true) {
    navButtons[0].checked = false;
  }
  //startingBoxes();
}

/* Checkbox Proportie */
/*var joinBtn = document.getElementById('join');
var createBtn = document.getElementById('create');
// if work option is selected, join will be disabled and viceverse
function createLock() { //Function that blocks work option
  if(joinBtn.checked == true) {
    createBtn.checked = false;
  } else if (joinBtn.checked == false) {
    createBtn.checked = true;
  }
}
function joinLock() { //Function that blocks join optiuon
  if(createBtn.checked == true) {
    joinBtn.checked = false;
  } else if (createBtn.checked == false) {
    joinBtn.checked = true;
  }
}*/

/* Dual Ramge Slider */
/*;(function() {
    "use strict";
    function dateFormat(date, fmt) {
        var o = {
            "M+": date.getMonth() + 1,
            "d+": date.getDate(),
        };
        if (/(y+)/.test(fmt)){
            fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
        }
        for (var k in o) {
            if (new RegExp("(" + k + ")").test(fmt)){
                fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
            }
        }
        return fmt;
    }
    var startDate = new Date("2017/01/01"),
        endDate = new Date("2017/12/31"),
        offset = endDate - startDate;
    $("#slider01").rangepicker({
       type: "double",
       startValue: dateFormat(startDate, "yyyy/MM/dd"),
       endValue: dateFormat(endDate, "yyyy/MM/dd"),
       translateSelectLabel: function(currentPosition, totalPosition) {
         var timeOffset = offset * ( currentPosition / totalPosition);
         var date = new Date(+startDate + parseInt(timeOffset));
         return dateFormat(date, "yyyy/MM/dd");
       }
    });
}());*/
