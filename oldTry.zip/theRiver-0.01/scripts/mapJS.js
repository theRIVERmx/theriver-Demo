var map;
var length;

//var filters = { stay: false, meet: false, create: false, join: false }
categorieButtons = document.getElementsByClassName('chkBtn');
conditionalButtons = document.getElementsByName('withCondition');
normalButtons = document.getElementsByName('withoutCondition');
markers = [];
titles = [];
infoPlace = [];
imagePlace = [];
categories = [];
openDays = [];
firstValues = [];
secondValues = [];
singleOBJ = [];

/* MAIN FUNCTION */ 



function starting() {

   /* SLIDER MODULE */
  var slider = document.getElementById('slider');
  noUiSlider.create(slider, {
    connect: [false, true, false],
    start: [1, 12 ],
    step: 1,
    range: { 'min': [ 1 ], 'max': [ 12 ] } });
    sliderArray = slider.noUiSlider.get();
    slider.noUiSlider.on('set', filter_markers);
  /* ----- ----- */

  for(var i = 0; i < categorieButtons.length; i++) {
    categorieButtons[i].checked = false;
  }

  for(var i = 0; i < normalButtons.length; i++) {
    normalButtons[i].onchange = filter_markers;
  }

  conditionalButtons[0].onchange = createCondition;
  conditionalButtons[1].onchange = joinCondition;

  function createCondition () {
    if(conditionalButtons[0].checked == true) {
      conditionalButtons[1].checked = false;
    }
    filter_markers();
  }

  function joinCondition () {
    if(conditionalButtons[1].checked == true) {
      conditionalButtons[0].checked = false;
    }
    filter_markers();
  }
}


var get_set_options = function() {
  buttonsStates = [];
  for(var i = 0; i < categorieButtons.length; i++) {
    if(categorieButtons[i].checked) {
      buttonsStates.push(categorieButtons[i].id);
    }
  }
  return buttonsStates;
}

var filter_markers = function() {

 
  //Variables
  set_filters = get_set_options();
  sliderArray = slider.noUiSlider.get();
  valuesButtons = [];
  valuesSlider = [];
  valuesEquals = [];

  console.log(set_filters);
  console.log(sliderArray);

  for(var i = 0; i < length; i++){
    single = singleOBJ[i];
    for(var j = 0; j < set_filters.length; j++) {
      if(single.properties.tags[set_filters[j]]) {
        valuesButtons[i] = markers[i];
      }
    }
  }

  for (var i = 0; i < length; i++) {
    if(firstValues[i] >= sliderArray[0] && secondValues[i] <= sliderArray[1]){
      valuesSlider[i] = markers[i];
    }
  }
  
  for(var i = 0; i < length; i++) {
    if(valuesButtons[i] && valuesSlider[i]) {
      valuesEquals[i] = markers[i];
    }
  }
  console.log(valuesButtons)
  console.log(valuesSlider)

  for(var i = 0; i < length; i++) {
    if(valuesEquals[i] || valuesEquals.length == 0) {
      markers[i].setVisible(true);  
    } else {
      markers[i].setVisible(false);
    }
  }
}



/* LOAD MARKERS */
function loadMarkers () {
  
  function loadJSON (callback) {
    var xObj = new XMLHttpRequest();
    xObj.overrideMimeType("application/json");
    xObj.open('GET', 'scripts/collection.geojson', true);
    xObj.onreadystatechange = function () {
      if(xObj.readyState == 4 && xObj.status == '200') {
        callback(xObj.responseText);
      }
    };
      xObj.send(null);
  }

  loadJSON(function(response) {
    
    //Parse
    json = JSON.parse(response);
    length = json.features.length; //Objective Length JSON
  
    //Get the JSON properties values
    for(var i = 0; i < length; i++) {
      singleOBJ[i] = json.features[i];
      categories[i] = json.features[i].properties.tags;
      openDays[i] = json.features[i].properties.open;
      titles = json.features[i].properties.title;
      infoPlace = json.features[i].properties.information;
      imagePlace = json.features[i].properties.image;
      firstValues[i] = openDays[i][0];
      secondValues[i] = openDays[i][1];
      coords = json.features[i].geometry.coordinates;
      point = new google.maps.LatLng(coords[0],coords[1]);
      marker = new google.maps.Marker({
        position: point,
        map: map,
        title: titles,
        icon: {
            path: 'M0,50 A50,50,0 1 1 100,50 A50,50,0 1 1 0,50 Z',
            fillColor: '#ff8a65',
            fillOpacity: 0.9,
            scale: 0.18,
            strokeColor: '#ff8a65'
          }
      });
      markers[i] = marker;
      infoMarkerBox();
      
    }
  });
}

function infoMarkerBox() {
      var markerInfo = "<div><h3>" + titles + "</h3><p>" + infoPlace + "</p><img src=" + imagePlace + "></div>"
      marker.addListener('click', function() {
          document.getElementById("boxInfo").style.width = "250px";
          document.getElementById("main").style.marginLeft = "250px";
          $('#information').html(markerInfo)
          return marker;
        });
}

function buttonAdd() {
  document.getElementById("buttonshop").addEventListener("click", function() {
    console.log(marker);
  });
}

function closeNav() {
    document.getElementById("boxInfo").style.width = "0px";
    document.getElementById("main").style.marginLeft = "0px";
}
/* ----- ------ */

starting();

function initMap() {
  var styledMapType = new google.maps.StyledMapType(
    [
      {
        "elementType": "geometry",
        "stylers": [
          {
            "color": "#f5f5f5"
          }
        ]
      },
      {
        "elementType": "labels",
        "stylers": [
          {
            "visibility": "off"
          }
        ]
      },
      {
        "elementType": "labels.icon",
        "stylers": [
          {
            "visibility": "off"
          }
        ]
      },
      {
        "elementType": "labels.text.fill",
        "stylers": [
          {
            "color": "#616161"
          }
        ]
      },
      {
        "elementType": "labels.text.stroke",
        "stylers": [
          {
            "color": "#f5f5f5"
          }
        ]
      },
      {
        "featureType": "administrative.land_parcel",
        "stylers": [
          {
            "visibility": "off"
          }
        ]
      },
      {
        "featureType": "administrative.land_parcel",
        "elementType": "labels.text.fill",
        "stylers": [
          {
            "color": "#bdbdbd"
          }
        ]
      },
      {
        "featureType": "administrative.neighborhood",
        "stylers": [
          {
            "visibility": "off"
          }
        ]
      },
      {
        "featureType": "poi",
        "elementType": "geometry",
        "stylers": [
          {
            "color": "#eeeeee"
          }
        ]
      },
      {
        "featureType": "poi",
        "elementType": "labels.text.fill",
        "stylers": [
          {
            "color": "#757575"
          }
        ]
      },
      {
        "featureType": "poi.park",
        "elementType": "geometry",
        "stylers": [
          {
            "color": "#e5e5e5"
          }
        ]
      },
      {
        "featureType": "poi.park",
        "elementType": "labels.text.fill",
        "stylers": [
          {
            "color": "#9e9e9e"
          }
        ]
      },
      {
        "featureType": "road",
        "elementType": "geometry",
        "stylers": [
          {
            "color": "#ffffff"
          }
        ]
      },
      {
        "featureType": "road.arterial",
        "elementType": "labels.text.fill",
        "stylers": [
          {
            "color": "#757575"
          }
        ]
      },
      {
        "featureType": "road.highway",
        "elementType": "geometry",
        "stylers": [
          {
            "color": "#dadada"
          }
        ]
      },
      {
        "featureType": "road.highway",
        "elementType": "labels.text.fill",
        "stylers": [
          {
            "color": "#616161"
          }
        ]
      },
      {
        "featureType": "road.local",
        "elementType": "labels.text.fill",
        "stylers": [
          {
            "color": "#9e9e9e"
          }
        ]
      },
      {
        "featureType": "transit.line",
        "elementType": "geometry",
        "stylers": [
          {
            "color": "#e5e5e5"
          }
        ]
      },
      {
        "featureType": "transit.station",
        "elementType": "geometry",
        "stylers": [
          {
            "color": "#eeeeee"
          }
        ]
      },
      {
        "featureType": "water",
        "elementType": "geometry",
        "stylers": [
          {
            "color": "#c9c9c9"
          }
        ]
      },
      {
        "featureType": "water",
        "elementType": "labels.text.fill",
        "stylers": [
          {
            "color": "#9e9e9e"
          }
        ]
      }
    ],
    {name: 'theRiver'});

  //console.log("InitMap");
  map_options = {
      zoom: 2,
      mapTypeId: google.maps.MapTypeId.ROADMAP,
      center: {lat: 20, lng: 0},
      mapTypeControlOptions: {
            mapTypeIds: ['styled_map'],
            position: google.maps.ControlPosition.TOP_BOTTOM
          },
      streetViewControl: false
    }
    map_document = document.getElementById('mapLake')
    map = new google.maps.Map(map_document,map_options);
    map.mapTypes.set('styled_map', styledMapType);
    map.setMapTypeId('styled_map');

  loadMarkers();
}
